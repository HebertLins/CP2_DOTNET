﻿namespace CLibrary_CP2
{
    public class Class1
    {

    }
}