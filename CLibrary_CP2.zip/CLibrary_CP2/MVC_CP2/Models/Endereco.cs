﻿namespace MVC_CP2.Model
{
    public class Endereco
    {

        public int id_endereco { get; set; }

        public String rua_endereco { get; set; }

        public String cidade_endereco { get; set; }

        public String uf_endereco { get; set; }

        public String cep_endereco { get; set; }

        public String numero_endereco { get; set; }

    }
}
